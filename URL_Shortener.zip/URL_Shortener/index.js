const express = require('express');
const path = require("path")
const { connectToMongoDB } = require('./connection');
const { URL } = require('./models/url'); // ✅ destructured correctly
const app = express();
const port = 8001;
const urlRoute = require('./routes/url');
const staticRoute = require('./routes/staticRouter')
const userRouter = require('./routes/user')
const cookieParser = require('cookie-parser')
const {restrictToLoggedinUserOnly,checkAuth} = require('./middlewares/auth')

// Connect to MongoDB
connectToMongoDB('mongodb://127.0.0.1:27017/short-url')
  .then(() => console.log("✅ Connected to MongoDB"))
  .catch((err) => console.error("❌ MongoDB connection error:", err));


app.set("view engine","ejs");
app.set("views", path.resolve("./views"))

// Middleware to parse JSON body
app.use(express.json());
app.use(express.urlencoded({extended:false}));
app.use(cookieParser())

// app.get("/test",async(req,res)=>{
//   const allUrls = await URL.find({});
//   return res.render('home')
// })

// Now register other routes
app.use('/url', restrictToLoggedinUserOnly, urlRoute);
app.use('/user', userRouter);
app.use('/', checkAuth, staticRoute);
// Routes
// ✅ Place this BEFORE app.use('/url')
app.get('/url/:shortId', async (req, res) => {
  const shortId = req.params.shortId;

  const entry = await URL.findOneAndUpdate(
    { shortId },
    {
      $push: { visitHistory: { timestamp: Date.now() } },
      $set: { updatedAt: new Date() }
    },
    { new: true }
  );

  if (!entry) return res.status(404).send("Short URL not found");

  // Auto-fix missing protocol
  const redirectURL = entry.redirectId.startsWith('http')
    ? entry.redirectId
    : 'https://' + entry.redirectId;

  return res.redirect(redirectURL);
});




// Start server
app.listen(port, () => console.log(`🚀 Server started at http://localhost:${port}`));
